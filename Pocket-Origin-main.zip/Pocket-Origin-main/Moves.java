/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pocketoriginextraobjects;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Copyright © 2022. all right reserved.
 * @author Judah Stasinos
 */
public class Moves {
    ArrayList<String> namesOfMoves = new ArrayList<>();
    int[] dmgOfMoves;
    
    public Moves() {
        namesOfMoves.add("Tackle");
        namesOfMoves.add("Flamethrower");
        namesOfMoves.add("Pound");
        namesOfMoves.add("Lightning");
        namesOfMoves.add("");
        
    }
    
}
